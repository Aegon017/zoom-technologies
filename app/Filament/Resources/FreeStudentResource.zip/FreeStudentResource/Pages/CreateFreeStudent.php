<?php

namespace App\Filament\Resources\FreeStudentResource\Pages;

use App\Filament\Resources\FreeStudentResource;
use Filament\Resources\Pages\CreateRecord;

class CreateFreeStudent extends CreateRecord
{
    protected static string $resource = FreeStudentResource::class;
}
